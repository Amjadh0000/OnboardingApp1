package com.example.onboardingapp

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment

class Fragment2 : Fragment(R.layout.fragment_2) {

    // تعريف الـ Interface للتواصل مع الـ Activity
    interface Fragment2Listener {
        fun onDataSent(name: String)
    }

    private var listener: Fragment2Listener? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        // ربط الـ Fragment بالـ Activity
        if (context is Fragment2Listener) {
            listener = context
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etName = view.findViewById<EditText>(R.id.etName)
        val btnContinue = view.findViewById<Button>(R.id.btnContinue)

        btnContinue.setOnClickListener {
            val name = etName.text.toString()
            if (name.isNotEmpty()) {
                // إرسال الاسم للـ Activity
                listener?.onDataSent(name)
            } else {
                etName.error = "Please enter your name"
            }
        }
    }
}