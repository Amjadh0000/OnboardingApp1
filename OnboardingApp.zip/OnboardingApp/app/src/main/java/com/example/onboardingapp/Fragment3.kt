package com.example.onboardingapp

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import androidx.fragment.app.Fragment

class Fragment3 : Fragment(R.layout.fragment_3) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvDisplayName = view.findViewById<TextView>(R.id.tvDisplayName)
        val cbConfirm = view.findViewById<CheckBox>(R.id.cbConfirm)
        val btnFinish = view.findViewById<Button>(R.id.btnFinish)

        // استلام الاسم المرسل من الـ Activity وعرضه[cite: 1]
        val name = arguments?.getString("user_name")
        tvDisplayName.text = "Welcome, $name!"

        // التحكم في حالة الزر بناءً على الـ CheckBox[cite: 1]
        cbConfirm.setOnCheckedChangeListener { _, isChecked ->
            btnFinish.isEnabled = isChecked
            btnFinish.text = if (isChecked) "Finish" else "Continue"
        }
    }
}