package com.example.onboardingapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), Fragment2.Fragment2Listener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // عرض Fragment2 عند تشغيل التطبيق[cite: 1]
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, Fragment2())
                .commit()
        }
    }

    // تنفيذ وظيفة الـ Interface لاستقبال الاسم والتبديل[cite: 1]
    override fun onDataSent(name: String) {
        val fragment3 = Fragment3()
        val bundle = Bundle()
        bundle.putString("user_name", name)
        fragment3.arguments = bundle

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment3)
            .addToBackStack(null) // للسماح بالعودة للخلف
            .commit()
    }
}